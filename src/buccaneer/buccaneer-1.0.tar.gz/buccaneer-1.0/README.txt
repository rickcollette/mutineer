Buccaneer Language Toolchain v1.0

Contents:
  bin/bucc        - CLI compiler and tools
  lib/libbuccvm.a - Static library for embedding
  include/        - Header files for C integration
  examples/       - Example Buccaneer programs

Usage:
  bucc compile <file.bucc>  - Compile to bytecode
  bucc run <file.bucc>      - Compile and execute
  bucc exec <file.bc>       - Execute bytecode
  bucc format <file.bucc>   - Format source code
  bucc lint <file.bucc>     - Check for issues
  bucc disasm <file.bc>     - Disassemble bytecode
